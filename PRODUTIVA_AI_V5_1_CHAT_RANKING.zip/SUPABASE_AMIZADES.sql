-- PRODUTIVA.AI V5 — Sistema de amizades (não altera tabelas atuais)
-- Execute no Supabase > SQL Editor, após fazer backup do projeto.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  created_at timestamptz not null default now(),
  constraint profiles_username_format check (username = lower(username) and username ~ '^[a-z0-9_]{3,24}$')
);
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  constraint friendships_not_self check (sender_id <> receiver_id)
);
-- Impede duplicidade nos dois sentidos (A->B e B->A).
create unique index if not exists friendships_pair_unique
  on public.friendships (least(sender_id, receiver_id), greatest(sender_id, receiver_id));
create index if not exists friendships_receiver_status_idx on public.friendships(receiver_id, status);
create index if not exists friendships_sender_status_idx on public.friendships(sender_id, status);
alter table public.profiles enable row level security;
alter table public.friendships enable row level security;
drop policy if exists "Profiles visible to authenticated users" on public.profiles;
create policy "Profiles visible to authenticated users" on public.profiles
  for select to authenticated using (true);
drop policy if exists "Users create own profile" on public.profiles;
create policy "Users create own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "Users view own friendships" on public.friendships;
create policy "Users view own friendships" on public.friendships
  for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "Users send friendship requests" on public.friendships;
create policy "Users send friendship requests" on public.friendships
  for insert to authenticated with check (auth.uid() = sender_id and sender_id <> receiver_id and status = 'pending');
drop policy if exists "Receiver accepts requests" on public.friendships;
create policy "Receiver accepts requests" on public.friendships
  for update to authenticated using (auth.uid() = receiver_id and status = 'pending')
  with check (auth.uid() = receiver_id and status in ('pending','accepted'));
drop policy if exists "Participants remove friendship" on public.friendships;
create policy "Participants remove friendship" on public.friendships
  for delete to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
-- Observação: perfis públicos expõem somente username/display_name nesta interface.
-- Não conceda acesso público a e-mail, tarefas, metas ou hábitos.
